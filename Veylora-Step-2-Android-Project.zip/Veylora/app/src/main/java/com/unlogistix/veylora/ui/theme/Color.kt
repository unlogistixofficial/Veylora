package com.unlogistix.veylora.ui.theme

import androidx.compose.ui.graphics.Color

val VeyloraBlack = Color(0xFF090909)
val VeyloraSurface = Color(0xFF151515)
val VeyloraGold = Color(0xFFD8B66A)
val VeyloraChampagne = Color(0xFFE8D5A5)
val VeyloraText = Color(0xFFF5F1E8)
val VeyloraMuted = Color(0xFFAAA39A)
