package com.unlogistix.veylora.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val VeyloraDarkColorScheme = darkColorScheme(
    primary = VeyloraGold,
    onPrimary = VeyloraBlack,
    secondary = VeyloraChampagne,
    background = VeyloraBlack,
    onBackground = VeyloraText,
    surface = VeyloraSurface,
    onSurface = VeyloraText,
    onSurfaceVariant = VeyloraMuted
)

@Composable
fun VeyloraTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = VeyloraDarkColorScheme,
        content = content
    )
}
