# Veylora ProGuard/R8 rules.
# Add reviewed keep rules only when a dependency requires them.
