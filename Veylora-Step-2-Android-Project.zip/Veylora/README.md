# Veylora

**Your Digital Life, Secured.**

Veylora is a premium, offline-first Android password manager designed to keep account credentials and attachments protected on the user's device.

## Project status

- [x] GitHub repository created
- [ ] Android project foundation
- [ ] Premium user interface
- [ ] Security and encrypted vault
- [ ] Account management and attachments
- [ ] Encrypted backup and restore
- [ ] Testing and release

## Planned principles

- Offline-first operation
- No advertising or tracking
- No account credentials sent to a server
- Encrypted local vault data
- User-controlled encrypted backup and restore
- Minimal Android permissions

## Technology

- Kotlin
- Native Android
- Jetpack Compose
- Android Keystore
- Room / reviewed encrypted storage
- Android Biometric APIs

## Security notice

Veylora is under active development. Do not store real passwords, recovery codes, private screenshots, or other sensitive information in development builds. Do not commit vault files, backups, signing keys, or secrets to GitHub.

Security features must be implemented and independently tested before the app is considered safe for real credentials.

## Build

The project is configured to build with Gradle 8.13 and JDK 17. GitHub Actions will build the debug APK on pushes and pull requests.

